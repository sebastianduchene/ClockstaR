partitions <-
function(bsd.object, ...) UseMethod("partitions")
